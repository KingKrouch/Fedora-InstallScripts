### CHANGELOG

#### Version 0.3.0

* support new Latte v0.9 Communication API
* add an option to use the current Latte icon size in order to work properly with Latte parabolic effect

#### Version 0.2

* Length option can support three different modes:
-- based on pixels
-- based on panel thickness
-- fill the entire available space
* improve configuration window in order to follow Window Applet(s) style
